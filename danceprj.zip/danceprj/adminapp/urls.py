from django.contrib import admin
from django.urls import path

from . import views

urlpatterns = [
    path('', views.adminhome),
    path('course2/',views.course2),
    path('courselist1/',views.courselist1),
    path('deleteentry/',views.deleteentry),
    path('editentry/',views.editentry),    
    path('searchcourse/',views.searchcourse),        
    path('logout1/',views.logout1), 
    path('batchentry1/',views.batchentry1),       

]