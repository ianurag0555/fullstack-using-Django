from django.db import models

# Create your models here.
class course1(models.Model):
    courseid=models.AutoField(primary_key=True)
    coursenm=models.CharField(max_length=25)
    duration=models.IntegerField()
    fees=models.IntegerField()
    coursedetail=models.CharField(max_length=200)


class testcourse(models.Model):
    imgid=models.AutoField(primary_key=True)
    courseimg=models.CharField(max_length=100)

class course2(models.Model):
    courseid=models.AutoField(primary_key=True)
    coursenm=models.CharField(max_length=25)
    duration=models.IntegerField()
    fees=models.IntegerField()
    coursedetail=models.CharField(max_length=200)
    courseimg=models.CharField(max_length=100) 

class batch1(models.Model):
 course2 = models.ForeignKey(course2, on_delete=models.CASCADE)     
 batchid=models.AutoField(primary_key=True)
 startdate=models.DateField()
 batchtime=models.CharField(max_length=30)
 facultyname=models.CharField(max_length=40)
 batchstatus=models.IntegerField()