from django.shortcuts import render,redirect
#for call admin model
from . import models as adminmodel

#for file uploading
from django.core.files.storage import FileSystemStorage

#for display file
from django.conf import settings
media_url=settings.MEDIA_URL

#for logout
from django.contrib.auth import logout

# Create your views here.
def adminhome(request):
 #for fetch data from session .........
 emailid=request.session.get("emailid")
 role=request.session.get("role")
 print("emailid ",emailid)
 print("role ",role)
 #.....................................
 return render(request,"admin1.html",{'emailid':emailid,'role':role})    

def course1(request):
 if request.method=="POST":
  coursenm=request.POST.get("coursenm")
  duration=request.POST.get("duration")
  fees=request.POST.get("fees")
  coursedetail=request.POST.get("coursedetail")
  obj=adminmodel.course1(coursenm=coursenm,duration=duration,fees=fees,coursedetail=coursedetail)
  obj.save()
  return render(request,"courseentry1.html",{'res':'Record Saved'})
 else: 
  return render(request,"courseentry1.html",{'res':''})

def test(request):
 if request.method=="POST":
  #for file uploading .................................
  courseicon=request.FILES["courseicon"]
  fs=FileSystemStorage()
  courseimg=fs.save(courseicon.name,courseicon)  
  #....................................................  
  obj=adminmodel.testcourse(courseimg=courseimg)
  obj.save()
  return render(request,"test.html")  
 else:
  return render(request,"test.html")

def testlist(request):
 obj=adminmodel.testcourse.objects.all()
 print(obj)
 return render(request,"testlist.html",{'obj':obj}) 

def courselist1(request):
 #select * from course2
 obj=adminmodel.course2.objects.all()
 print(obj)
 return render(request,"courselist1.html",{'obj':obj,'media_url':media_url})

def deleteentry(request):
 courseid=request.GET.get("courseid")
 print("course id =",courseid)
 obj=adminmodel.course1.objects.get(courseid=courseid)
 obj.delete()
 return redirect("/admin1/courselist1/")

def editentry(request):
 if request.method=="GET":
  #for fetch data from query string
  courseid=request.GET.get("courseid") 
  obj=adminmodel.course2.objects.filter(courseid=courseid).values()
  print(obj)
  return render(request,"updatecourse.html",{'obj':obj})
 else:
  courseid=request.GET.get("courseid")
  coursenm=request.POST.get("coursenm")  
  duration=request.POST.get("duration")
  fees=request.POST.get("fees")
  coursedetail=request.POST.get("coursedetail")
  adminmodel.course2.objects.filter(courseid=courseid).update(coursenm=coursenm,duration=duration,fees=fees,coursedetail=coursedetail)
  
  return redirect("/admin1/courselist1/")

def searchcourse(request):
 if request.method=="POST":
  courseid=request.POST.get("courseid")
  obj=adminmodel.course1.objects.filter(courseid=courseid).values()
  print(obj)
  return render(request,"search.html",{'obj':obj})
 else:
  return render(request,"search.html",{'obj':''})

def course2(request):
 if request.method=="POST":
  coursenm=request.POST.get("coursenm")
  duration=request.POST.get("duration")
  fees=request.POST.get("fees")
  coursedetail=request.POST.get("coursedetail")
  #for get file detail ................
  courseicon=request.FILES["courseicon"]
  fs=FileSystemStorage()
  courseimg=fs.save(courseicon.name,courseicon)  
  #......................................
  obj=adminmodel.course2(coursenm=coursenm,duration=duration,fees=fees,coursedetail=coursedetail,courseimg=courseimg)
  obj.save()
  return render(request,"courseentry2.html",{'res':'Record Saved'})
 else: 
  return render(request,"courseentry2.html",{'res':''})

def logout1(request):
  logout(request)
  return redirect('http://localhost:8000/')

def batchentry1(request):
 obj=adminmodel.course2.objects.all()
 if request.method=="POST":
  startdate=request.POST.get("startdate")
  batchtime=request.POST.get("batchtime")
  facultyname=request.POST.get("facultyname")
  batchstatus=1
  courseid=request.POST.get("courseid")
  obj=adminmodel.batch1(startdate=startdate,batchtime=batchtime,facultyname=facultyname,batchstatus=batchstatus,course2_id=courseid)
  obj.save()
  return render(request,"batchentry1.html",{'obj':obj,'res':'Record Saved'})
 else:
  return render(request,"batchentry1.html",{'obj':obj,'res':''})

