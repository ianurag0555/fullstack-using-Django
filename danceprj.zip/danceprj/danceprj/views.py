from django.shortcuts import render,redirect
from . import models

#for call admin app models in main app
from adminapp.models import course2
from adminapp.models import batch1

from django.conf import settings
media_url=settings.MEDIA_URL

def home(request):
    if request.method=="POST":
       emailid=request.POST.get("emailid")
       pwd=request.POST.get("pwd")
       res=models.registers.objects.filter(emailid=emailid,pwd=pwd)
       role=res[0].role
       #for create session ------------------
       if len(res)>0: 
        request.session["emailid"]=emailid
        request.session["role"]=role 
       #---------------------------------------
        if role=="admin":
           return redirect("/admin1/")
        else:
           return redirect("/student1/")
       
       return render(request,"index.html")
    else:   
     return render(request,"index.html")

def about(request):
    return render(request,"about.html")

def register(request):
    if request.method=="POST":
     fnm=request.POST.get("fnm")
     mno=request.POST.get("mno")
     emailid=request.POST.get("emailid")
     pwd=request.POST.get("pwd")
     role="student"
     obj=models.registers(fnm=fnm,mno=mno,emailid=emailid,pwd=pwd,role=role)
     obj.save()
     #for email id -----------------------------
     #emailAPI.sendEmail(emailid,pwd)	
     #-------------------------------------------  	
     return render(request,"register.html",{'res':'Record Saved'})
    else:
     return render(request,"register.html",{'res':''})  

def userlist(request):
    obj=models.registers.objects.all()
    #print(obj)
    return render(request,"userlist.html",{'obj':obj})    

def adminhome(request):
    return render(request,"adminhome.html")

def courselist(request):
 obj=course2.objects.all()
 print(obj)
 return render(request,"courselist.html",{'obj':obj,'media_url':media_url})

def batchlist1(request):
   s="""select a.batchid,b.coursenm,b.duration,b.fees,a.startdate,a.batchtime,a.facultyname
     from adminapp_batch1 as a
     inner join adminapp_course2 as b on a.course2_id=b.courseid
     where a.batchstatus=1"""
   res=batch1.objects.raw(s)
   
   return render(request,"batchlist1.html",{'res':res})     
