from django.db import models

class registers(models.Model):
    regid=models.AutoField(primary_key=True)
    fnm=models.CharField(max_length=25)
    mno=models.BigIntegerField()    
    emailid=models.CharField(max_length=40)    
    pwd=models.CharField(max_length=13)
    role=models.CharField(max_length=15)

