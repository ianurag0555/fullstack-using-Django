from django.contrib import admin
from django.urls import path,include
#for file uploading .......................
from django.conf.urls.static import static
from django.conf import settings
#.....................................
from . import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.home),
    path('about/',views.about),
    path('register/',views.register),
    path('userlist/',views.userlist),    
    path('courselist/',views.courselist),    
    path('admin1/',include('adminapp.urls')),
    path('student1/',include('studentapp.urls')),   
    path('batchlist1/',views.batchlist1),
]+static(settings.MEDIA_URL,
document_root=settings.MEDIA_ROOT)
