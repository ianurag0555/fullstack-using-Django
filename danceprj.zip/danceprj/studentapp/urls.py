from django.contrib import admin
from django.urls import path

from . import views

urlpatterns = [
    path('', views.studenthome),
    path('logout2/',views.logout2),
    path('courselist2/',views.courselist2),
    path('batchlist2/',views.batchlist2),
    path('admission/',views.admission),
]