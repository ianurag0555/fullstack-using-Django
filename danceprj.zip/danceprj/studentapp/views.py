from django.shortcuts import render,redirect

#for logout
from django.contrib.auth import logout

#for call admin app models in main app
from adminapp.models import course2
from adminapp.models import batch1

from django.conf import settings
media_url=settings.MEDIA_URL

# Create your views here.
def studenthome(request):
 #for fetch data from session .........
 emailid=request.session.get("emailid")
 role=request.session.get("role")
 print("emailid ",emailid)
 print("role ",role)
 #.....................................
 return render(request,"student1.html",{'emailid':emailid,'role':role})    

def logout2(request):
  logout(request)
  return redirect('http://localhost:8000/')

def courselist2(request):
 obj=course2.objects.all()
 print(obj)
 return render(request,"courselist2.html",{'obj':obj,'media_url':media_url})

def admission(request):
  if request.method=="GET":
   batchid=request.GET.get("batchid")
   print(batchid)
   s="""select a.batchid,b.coursenm,b.duration,b.fees,a.startdate,a.batchtime,a.facultyname
     from adminapp_batch1 as a
     inner join adminapp_course2 as b on a.course2_id=b.courseid
     where a.batchid="""+batchid
   obj=batch1.objects.raw(s)
   print(obj)
   return render(request,"admission.html",{'obj':obj})


def batchlist2(request):
   s="""select a.batchid,b.coursenm,b.duration,b.fees,a.startdate,a.batchtime,a.facultyname
     from adminapp_batch1 as a
     inner join adminapp_course2 as b on a.course2_id=b.courseid
     where a.batchstatus=1"""
   res=batch1.objects.raw(s)   
   return render(request,"batchlist2.html",{'res':res})     


